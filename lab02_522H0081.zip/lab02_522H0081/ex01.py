for i in range(50, 100, 1):
    if i % 2 == 1:
        print(i)
