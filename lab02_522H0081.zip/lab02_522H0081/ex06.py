import numpy as np
arr=np.arange(12, 38+1, 1)
print(type(arr))
print(arr)