for i in range(0, 20+1, 1):
    if i == 3 or i == 16 :
        continue
    print(i)