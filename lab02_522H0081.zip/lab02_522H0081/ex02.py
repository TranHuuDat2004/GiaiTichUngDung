for i in range(1500, 2700, 1):
    if i % 7 == 0 and i % 5 == 0:
        print(i)
